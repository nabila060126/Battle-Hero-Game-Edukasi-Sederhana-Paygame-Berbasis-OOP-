import pygame
import sys
import os
import random  


# ENCAPSULATION: Kelas untuk mengelola audio dengan atribut private
class AudioManager:
    def __init__(self):
        self._enabled = False  # Private attribute
        self._background_music = None
        self._click_sound = None
        self._volume = 0.7
    
    def initialize(self):
        """Initialize audio system"""
        try:
            pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=512)
            pygame.mixer.init()
            self._enabled = True
            return True
        except pygame.error as e:
            print(f"Audio initialization failed: {e}")
            return False
    
    def load_sounds(self):
        """Load semua sound"""
        if not self._enabled:
            return
        
        try:
            # Load background music
            bg_music_path = "background_musik.mp3"
            if os.path.exists(bg_music_path):
                pygame.mixer.music.load(bg_music_path)
                pygame.mixer.music.set_volume(0.5)
                pygame.mixer.music.play(-1)
                print("Background music loaded successfully")
            
            # Load sound efek klik
            click_sound_path = "click.wav.mp3"
            if os.path.exists(click_sound_path):
                self._click_sound = pygame.mixer.Sound(click_sound_path)
                self._click_sound.set_volume(self._volume)
                print("Click sound loaded successfully")
        except Exception as e:
            print(f"Error loading sounds: {e}")
    
    def play_click(self):
        """Play click sound"""
        if self._click_sound and self._enabled:
            try:
                self._click_sound.play()
            except Exception as e:
                print(f"Error playing sound: {e}")
    
    @property
    def enabled(self):
        """Getter untuk enabled status"""
        return self._enabled
    
    @property
    def click_sound(self):
        """Getter untuk click sound"""
        return self._click_sound

# INHERITANCE: Base class untuk semua tombol
class BaseButton:
    def __init__(self, x, y, image, audio_manager):
        self.rect = image.get_rect(topleft=(x, y))
        self.image = image
        self.audio_manager = audio_manager
    
    def draw(self, screen):
        """Draw tombol ke screen"""
        screen.blit(self.image, self.rect)
    
    def is_clicked(self):
        """Check jika tombol diklik"""
        click = pygame.mouse.get_pressed()[0]
        if self.rect.collidepoint(pygame.mouse.get_pos()) and click:
            self.audio_manager.play_click()
            pygame.time.delay(180)
            return True
        return False

# POLYMORPHISM: Tombol normal vs tombol terkunci
class NormalButton(BaseButton):
    """Tombol normal yang bisa diklik"""
    def __init__(self, x, y, image, audio_manager):
        super().__init__(x, y, image, audio_manager)
    
    def is_clicked(self):
        """Override method untuk tombol normal"""
        return super().is_clicked()

class LockedButton(BaseButton):
    """Tombol terkunci yang tidak bisa diklik"""
    def __init__(self, x, y, image, audio_manager):
        super().__init__(x, y, image, audio_manager)
        # Buat overlay gelap
        self.image = create_dark_overlay(image)
    
    def is_clicked(self):
        """Override method untuk mencegah klik"""
        return False  # Selalu return False karena terkunci

# ENCAPSULATION: Kelas untuk mengelola soal quiz
class QuizQuestion:
    def __init__(self, question, answer):
        self._question = question  # Private attribute
        self._answer = answer      # Private attribute
    
    @property
    def question(self):
        """Getter untuk soal"""
        return self._question
    
    @property
    def answer(self):
        """Getter untuk jawaban"""
        return self._answer
    
    def normalize_text(self, text):
        """Normalisasi teks untuk perbandingan"""
        t = text.replace(" ", "").replace("\n", "").replace("\t", "").lower()
        for c in [';', ':', ',', '"', "'"]:
            t = t.replace(c, "")
        return t
    
    def check_answer(self, user_answer):
        """Cek jawaban user"""
        user_normalized = self.normalize_text(user_answer)
        correct_normalized = self.normalize_text(self._answer)
        return user_normalized == correct_normalized

# COMPOSITION: Kelas untuk mengelola level
class Level:
    def __init__(self, level_number, dialogs, background_img, character_img):
        self.level_number = level_number
        self.dialogs = dialogs
        self.background_img = background_img
        self.character_img = character_img
        self.unlocked = False
        self.completed = False
    
    def unlock(self):
        """Unlock level ini"""
        self.unlocked = True
    
    def complete(self):
        """Tandai level sebagai selesai"""
        self.completed = True
    
    def get_current_dialog(self, index):
        """Dapatkan dialog berdasarkan index"""
        if 0 <= index < len(self.dialogs):
            return self.dialogs[index]
        return ""


# FUNGSI EXISTING YANG TIDAK BERUBAH
# ============================================

def initialize_audio():
    """Fungsi untuk menginisialisasi audio dengan penanganan error"""
    try:
        # Konfigurasi audio yang optimal
        pygame.mixer.pre_init(
            frequency=44100,
            size=-16,
            channels=2,
            buffer=512
        )
        pygame.mixer.init()
        return True
    except pygame.error as e:
        print(f"Audio initialization failed: {e}")
        print("Game will run without audio")
        return False

def render_text_multiline(text, x, y, font, color, max_width):
    """Render teks dengan auto-wrap berdasarkan lebar maksimum"""
    words = text.split(" ")
    lines = []
    current_line = ""

    # Proses pembuatan baris berdasarkan lebar
    for word in words:
        test_line = current_line + word + " "
        test_surf = font.render(test_line, True, color)

        if test_surf.get_width() > max_width:
            lines.append(current_line)
            current_line = word + " "
        else:
            current_line = test_line

    lines.append(current_line)

    # Render setiap baris ke layar
    for line in lines:
        surf = font.render(line, True, color)
        screen.blit(surf, (x, y))
        y += surf.get_height() + 5  # Spasi antar baris

def create_dark_overlay(button_img, alpha=180):
    """Membuat overlay gelap untuk tombol yang terkunci"""
    dark = button_img.copy()
    black_layer = pygame.Surface(button_img.get_size(), pygame.SRCALPHA)
    black_layer.fill((0, 0, 0, alpha))
    dark.blit(black_layer, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    return dark

def image_btn(image, x, y):
    """Membuat tombol dari gambar dengan feedback klik"""
    rect = image.get_rect(topleft=(x, y))
    screen.blit(image, rect)
    click = pygame.mouse.get_pressed()[0]
    
    # Cek jika tombol diklik
    if rect.collidepoint(pygame.mouse.get_pos()) and click:
        # Mainkan sound efek jika tersedia
        if sound_click is not None:
            try:
                sound_click.play()
            except Exception as e:
                print(f"Error playing sound: {e}")
        pygame.time.delay(180)  # Delay kecil untuk feedback
        return True
    return False


# INISIALISASI 
# ============================================

# Inisialisasi Pygame
pygame.init()

# Buat instance AudioManager (OOP)
audio_manager = AudioManager()
audio_enabled = audio_manager.initialize()

# Load sounds menggunakan AudioManager
if audio_enabled:
    audio_manager.load_sounds()
    sound_click = audio_manager.click_sound
else:
    print("Audio disabled. Game will run without sound.")
    sound_click = None


# KONFIGURASI WINDOW 
# ============================================
WIDTH, HEIGHT = 800, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("PayGame Edukasi")


# KONSTANTA WARNA 
# ============================================
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (80, 140, 255)

# KONFIGURASI FONT 
# ============================================
font_btn = pygame.font.SysFont("arial", 32)

# VARIABEL STATE GAME 
# ============================================
page = "menu"           # Halaman aktif: menu, dialog, level, quiz, winner
level = 0               # Level saat ini (1, 2, 3)
dialog_index = 0        # Indeks dialog utama
level_dialog_index = 0  # Indeks dialog level
input_text = ""         # Input teks dari user di quiz
answered = []           # Riwayat jawaban
quiz_number = 0         # Nomor soal dalam level 
winner_timer = 0        # Timer untuk tampilan winner


# SISTEM LEVEL UNLOCK 
# ============================================
unlocked_level = 1  # Level yang sudah terbuka (default: level 1)

# VARIABEL NOTIFIKASI 
# ============================================
notif_quiz = ""  # Notifikasi untuk feedback jawaban quiz

# DATA DIALOG CERITA 
# ============================================
# Dialog utama (pembuka game)
dialogs = [
    "Selamat Datang dalam Arena Perang",
    "Banyak Musuh yang Sedang Menunggu Anda",
    "Selesaikan Misi dan Kalahkan Musuh",
    "Selamat Berperang!"
]

# Dialog per level
dialog_level1 = [
    "Selamat datang di Level 1!",
    "Perkenalkan Saya Jelly",
    "Musuh Anda di Level ini",
    "Mari Kalahkan Saya!!",
    "Semoga Kemenangan Berpihak Pada Anda"
]

dialog_level2 = [
    "Selamat datang di Level 2!",
    "Perkenalkan Saya Mummis",
    "Musuh Anda di Level ini",
    "Mari Kalahkan Saya!!",
    "Semoga Kemenangan Berpihak Pada Anda"
]

dialog_level3 = [
    "Selamat datang di Level 3!",
    "Perkenalkan Saya Ablis",
    "Musuh Anda di Level ini",
    "Mari Kalahkan Saya!!",
    "Semoga Kemenangan Berpihak Pada Anda"
]

# DATA QUIZ DENGAN OOP (MODIFIKASI KECIL)
# ============================================
# QuizQuestion untuk setiap soal (OOP)
quiz_questions = {
    1: [
        QuizQuestion(
            "Budi ingin menyapa semua temannya lewat komputer. "
            "Tulislah program yang menampilkan tulisan: Halo, Budi!",
            'print("Halo, Budi!")'
        ),
        QuizQuestion(
            "Di sekolah, bel pagi berbunyi 3 kali untuk memanggil para siswa. "
            "Buat program yang menampilkan tulisan 'Selamat pagi semuanya!' sebanyak 3 kali.",
            'for i in range(3): print("Selamat pagi semuanya!")'
        ),
        QuizQuestion(
            "Doni punya 3 permen, lalu ibunya memberi 5 permen lagi."
            "Buat program untuk menghitung total permen Doni.",
            'hasil = 3 + 5\nprint(hasil)'
        ),
        QuizQuestion(
            "Di taman sekolah ada ubin berbentuk persegi dengan panjang sisi 4 cm."
            "Buat program untuk menghitung luas ubin persegi tersebut.",
            'sisi = 4 luas = sisi * sisi print(luas)'
        ),
        QuizQuestion(
            "Robot mini mempunyai tenaga sebesar angka 4, dan ketika diaktifkan, tenaganya menjadi dua kali lipat."
            "Buat program untuk menampilkan kekuatan robot setelah digandakan.",
            'angka = 4 print(angka * 2)'
        )
    ],
    2: [
        QuizQuestion(
            "Diberikan list angka: [2, 4, 6, 8]."
            "Buat program untuk menjumlahkan semua angkanya.",
            'angka = [2,4,6,8] total = sum(angka) print(total)'
        ),
        QuizQuestion(
            "Jika jumlah = 4, tampilkan kata 'Belajar' sebanyak 4 kali.",
            'jumlah = 4 for i in range(jumlah): print("Belajar")'
        ),
        QuizQuestion(
            "Ubah variabel warna 'merah' menjadi 'biru' lalu tampilkan",
            'warna = "merah" warna = "biru" print(warna)'
        ),
        QuizQuestion(
            "Hitung berapa huruf 'a' dalam kata 'cerita'",
            'print("cerita".count("a"))'
        )
    ],
    3: [
        QuizQuestion(
            "Budi ingin memperkenalkan dirinya kepada teman-teman di kelas."
            "Buatlah program Python sederhana yang menampilkan perkenalan Budi di layar."
            "'Perkenalkan aku Budi,umur aku 5 thn'",
            'nama = "Budi" umur = 5 print(f"Perkenalkan aku {nama},umur aku {umur} thn")'
        )
    ]
}

# Buat dictionary quiz lama untuk kompatibilitas
quiz = {}
for level_num, questions in quiz_questions.items():
    quiz[level_num] = []
    for q in questions:
        quiz[level_num].append((q.question, q.answer))


# ASSET GAMBAR 
# ============================================
try:
    # Background utama
    bg_menu = pygame.transform.scale(pygame.image.load("baground utama.png"), (WIDTH, HEIGHT))
    bg_dialog = pygame.transform.scale(pygame.image.load("bagorund dialog.png"), (WIDTH, HEIGHT))
    bg_level = pygame.transform.scale(pygame.image.load("Baground level.png"), (WIDTH, HEIGHT))
    
    # Background dialog per level
    bg_dialoglevel1 = pygame.transform.scale(pygame.image.load("bg_level_1.jpg"), (WIDTH, HEIGHT))
    bg_dialoglevel2 = pygame.transform.scale(pygame.image.load("bg_level_2.jpg"), (WIDTH, HEIGHT))
    bg_dialoglevel3 = pygame.transform.scale(pygame.image.load("bg_level_3.jpg"), (WIDTH, HEIGHT))
    
    # Karakter utama dan musuh setiap level
    char_img = pygame.transform.scale(pygame.image.load("karakter utama.png"), (430, 550))
    char_imglevel1 = pygame.transform.scale(pygame.image.load("karakter level 1.png"), (430, 550))
    char_imglevel2 = pygame.transform.scale(pygame.image.load("karakter level 2.png"), (430, 550))
    char_imglevel3 = pygame.transform.scale(pygame.image.load("karakter level 3.png"), (430, 550))
    
    # Tombol-tombol navigasi
    btn_play = pygame.transform.scale(pygame.image.load("PLAY.png"), (230, 240))
    btn_next = pygame.transform.scale(pygame.image.load("NEXT.png"), (100, 120))
    btn_skip = pygame.transform.scale(pygame.image.load("SKIP.png"), (100, 120))
    btn_back = pygame.transform.scale(pygame.image.load("back.png"), (140, 150))
    
    # Tombol setiap level
    btn_level1 = pygame.transform.scale(pygame.image.load("level 1.png"), (230, 240))
    btn_level2 = pygame.transform.scale(pygame.image.load("level 2.png"), (230, 240))
    btn_level3 = pygame.transform.scale(pygame.image.load("level 3.png"), (230, 240))
    
    # tampilan Tombol jawab 
    try:
        label_jawab_img = pygame.image.load("Jawab.png").convert_alpha()
    except:
        print("Warning: Jawab.png not found, creating placeholder")
        # Placeholder tombol jawab
        label_jawab_img = pygame.Surface((170, 170), pygame.SRCALPHA)
        pygame.draw.rect(label_jawab_img, (60, 140, 255), (0, 0, 170, 170), border_radius=10)
        font_jawab = pygame.font.SysFont("arialblack", 26)
        text_jawab = font_jawab.render("JAWAB", True, WHITE)
        label_jawab_img.blit(text_jawab, (35, 70))
        
except Exception as e:
    print(f"Error loading images: {e}")
    pygame.quit()
    sys.exit()


# BUAT LEVEL DENGAN OOP 
# ============================================

# Buat instance Level untuk setiap level
level1 = Level(1, dialog_level1, bg_dialoglevel1, char_imglevel1)
level2 = Level(2, dialog_level2, bg_dialoglevel2, char_imglevel2)
level3 = Level(3, dialog_level3, bg_dialoglevel3, char_imglevel3)

# Unlock level 1 secara default
level1.unlock()

# Dictionary untuk akses level
levels = {1: level1, 2: level2, 3: level3}


# BUAT TOMBOL DENGAN OOP 
# ============================================

# Buat tombol dengan OOP
play_button = NormalButton(280, 180, btn_play, audio_manager)
next_button = NormalButton(540, 400, btn_next, audio_manager)
skip_button = NormalButton(650, 400, btn_skip, audio_manager)
back_button = NormalButton(20, 20, btn_back, audio_manager)

# Tombol level dengan polymorphism
level1_button = NormalButton(290, 100, btn_level1, audio_manager)
level2_button = NormalButton(290, 200, btn_level2, audio_manager) if unlocked_level >= 2 else LockedButton(290, 200, btn_level2, audio_manager)
level3_button = NormalButton(290, 300, btn_level3, audio_manager) if unlocked_level >= 3 else LockedButton(290, 300, btn_level3, audio_manager)


# GAME LOOP
# ============================================
clock = pygame.time.Clock()
mouse_clicked = False  # Flag untuk mencegah klik berulang
running = True  # Flag utama game loop

while running:
    clock.tick(60)  # 60 FPS
    
    # EVENT HANDLING 
    # ============================================
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        
        # Handle input keyboard di halaman quiz
        if page == "quiz" and event.type == pygame.KEYDOWN:
            # Hapus karakter dengan backspace
            if event.key == pygame.K_BACKSPACE:
                input_text = input_text[:-1]
            
            # Submit jawaban dengan Enter
            elif event.key == pygame.K_RETURN:
                # Gunakan QuizQuestion untuk cek jawaban
                if quiz_number < len(quiz_questions[level]):
                    current_question = quiz_questions[level][quiz_number]
                    
                    if current_question.check_answer(input_text):
                        answered.append(f"Soal {quiz_number + 1}: ✔")
                        quiz_number += 1
                        
                        # Jika semua soal selesai
                        if quiz_number >= len(quiz_questions[level]):
                            # Jika level 3 selesai, tampilkan winner screen
                            if level == 3:
                                page = "winner"
                                winner_timer = pygame.time.get_ticks()
                            else:
                                # Untuk level 1 dan 2, unlock level berikutnya
                                if level < 3:
                                    unlocked_level = max(unlocked_level, level + 1)
                                    # Update tombol dengan polymorphism
                                    if level == 1:
                                        level2_button = NormalButton(290, 200, btn_level2, audio_manager)
                                    elif level == 2:
                                        level3_button = NormalButton(290, 300, btn_level3, audio_manager)
                                    
                                    # Unlock level di OOP
                                    levels[level + 1].unlock()
                                
                                quiz_number = 0
                                page = "level"
                            notif_quiz = ""
                        else:
                            notif_quiz = "Jawaban Anda BENAR!"
                    else:
                        answered.append(f"Soal {quiz_number + 1}: ✘ ({input_text})")
                        notif_quiz = "Jawaban Anda SALAH!"
                    
                    input_text = ""
            
            # Tambah karakter biasa
            else:
                input_text += event.unicode
    
    
    
    # PAGE: MENU UTAMA (DENGAN OOP)
    # ============================================
    if page == "menu":
        screen.blit(bg_menu, (0, 0))
        
        # Gunakan tombol OOP
        play_button.draw(screen)
        if play_button.is_clicked():
            page = "dialog"
    
    
    # PAGE: DIALOG UTAMA (DENGAN OOP)
    # ============================================
    elif page == "dialog":
        screen.blit(bg_dialog, (0, 0))
        screen.blit(char_img, (10, 0))
        
        # Buat kotak dialog
        dialog_box = pygame.Rect(50, 360, 700, 120)
        pygame.draw.rect(screen, WHITE, dialog_box, border_radius=18)
        pygame.draw.rect(screen, BLACK, dialog_box, 5, border_radius=18)
        
        # Render teks dialog
        text = dialogs[dialog_index]
        surf = pygame.font.SysFont("arialblack", 27).render(text, True, BLACK)
        screen.blit(surf, (70, 395))
        
        # Gunakan tombol OOP
        next_button.draw(screen)
        skip_button.draw(screen)
        
        if next_button.is_clicked():
            dialog_index += 1
        
        if skip_button.is_clicked():
            dialog_index = len(dialogs)
        
        # Jika dialog selesai, lanjut ke level selection
        if dialog_index >= len(dialogs):
            page = "level"
    
    
    # PAGE: LEVEL SELECTION (DENGAN OOP)
    # ============================================
    elif page == "level":
        screen.blit(bg_level, (0, 0))
        
        # Gunakan tombol OOP dengan polymorphism
        back_button.draw(screen)
        level1_button.draw(screen)
        level2_button.draw(screen)
        level3_button.draw(screen)
        
        # LEVEL 1 (selalu terbuka)
        if level1_button.is_clicked():
            level = 1
            level_dialog_index = 0
            page = "dialog_level"
        
        # LEVEL 2 (tergantung unlock status) - polymorphism
        if unlocked_level >= 2 and level2_button.is_clicked():
            level = 2
            level_dialog_index = 0
            page = "dialog_level"
        
        # LEVEL 3 (tergantung unlock status) - polymorphism
        if unlocked_level >= 3 and level3_button.is_clicked():
            level = 3
            level_dialog_index = 0
            page = "dialog_level"
        
        # Tombol kembali ke menu
        if back_button.is_clicked():
            page = "menu"
            dialog_index = 0
    
    
    # PAGE: DIALOG LEVEL (DENGAN OOP)
    # ============================================
    elif page == "dialog_level":
        # Gunakan Level class untuk mendapatkan data
        current_level = levels[level]
        
        # Render background dan karakter dari Level object
        screen.blit(current_level.background_img, (0, 0))
        screen.blit(current_level.character_img, (10, 0))
        
        # Kotak dialog
        dialog_box = pygame.Rect(50, 360, 700, 120)
        pygame.draw.rect(screen, WHITE, dialog_box, border_radius=18)
        pygame.draw.rect(screen, BLACK, dialog_box, 5, border_radius=18)
        
        # Render teks dialog dari Level object
        text = current_level.get_current_dialog(level_dialog_index)
        surf = pygame.font.SysFont("arialblack", 27).render(text, True, BLACK)
        screen.blit(surf, (70, 395))
        
        # Gunakan tombol OOP
        next_button.draw(screen)
        skip_button.draw(screen)
        
        if next_button.is_clicked():
            level_dialog_index += 1
        
        if skip_button.is_clicked():
            level_dialog_index = len(current_level.dialogs)
        
        # Jika dialog selesai, lanjut ke quiz
        if level_dialog_index >= len(current_level.dialogs):
            page = "quiz"
    
    
    # PAGE: QUIZ (DENGAN OOP)
    # ============================================
    elif page == "quiz":
        screen.fill(WHITE)
        
        # Ambil soal dari QuizQuestion object
        current_question = quiz_questions[level][quiz_number]
        soal = current_question.question
        jawab = current_question.answer
        
        # Judul level
        surf = pygame.font.SysFont("arialblack", 50).render(f"LEVEL {level}", True, BLUE)
        screen.blit(surf, (WIDTH / 2 - surf.get_width() / 2, 40))
        
        # Render soal (multiline)
        font_question = pygame.font.SysFont("arialblack", 24)
        render_text_multiline(soal, 50, 150, font_question, BLACK, max_width=670)
        
        # ================= INPUT BOX =================
        font = pygame.font.SysFont("arialblack", 12)
        text_surf = font.render(input_text, True, BLACK)
        
        # Lebar input box dinamis
        min_width = 200
        max_width = 500
        padding = 20
        
        box_width = max(min_width, text_surf.get_width() + padding)
        box_width = min(box_width, max_width)
        
        # Buat dan render input box
        input_box_rect = pygame.Rect(50, 300, box_width, 50)
        pygame.draw.rect(screen, WHITE, input_box_rect, border_radius=10)
        pygame.draw.rect(screen, BLACK, input_box_rect, 3, border_radius=10)
        
        # Render teks input
        screen.blit(text_surf, (input_box_rect.x + 10, input_box_rect.y + 10))
        
        # ================= TOMBOL JAWAB =================
        btn_jawab = pygame.Rect(540, 230, 180, 180)
        label_jawab = pygame.transform.scale(label_jawab_img, (btn_jawab.width, btn_jawab.height))
        screen.blit(label_jawab, (btn_jawab.x, btn_jawab.y))
        
        # ================= NOTIFIKASI HASIL =================
        if notif_quiz != "":
            color = (0, 180, 0) if "BENAR" in notif_quiz else (200, 0, 0)
            notif_surf = pygame.font.SysFont("arialblack", 28).render(notif_quiz, True, color)
            screen.blit(notif_surf, (50, 370))
        
        # ================= HANDLE MOUSE CLICK =================
        if pygame.mouse.get_pressed()[0] and not mouse_clicked:
            mouse_clicked = True
            
            # Gunakan AudioManager untuk play sound
            audio_manager.play_click()
            
            mx, my = pygame.mouse.get_pos()
            
            # Tombol kembali ke level selection 
            if image_btn(btn_back, 20, 20):
                quiz_number = 0
                notif_quiz = ""
                page = "level"
            
            # Tombol "JAWAB" ditekan
            if btn_jawab.collidepoint(mx, my):
                # Gunakan method dari QuizQuestion untuk cek jawaban
                if current_question.check_answer(input_text):
                    notif_quiz = "Jawaban Anda BENAR!"
                    quiz_number += 1
                    
                    # Jika semua soal selesai
                    if quiz_number >= len(quiz_questions[level]):
                        # Jika level 3 selesai, tampilkan winner screen
                        if level == 3:
                            page = "winner"
                            winner_timer = pygame.time.get_ticks()
                            # Tandai level sebagai selesai di OOP
                            levels[level].complete()
                        else:
                            # Untuk level 1 dan 2, unlock level berikutnya
                            if level < 3:
                                unlocked_level = max(unlocked_level, level + 1)
                                # Update tombol dengan polymorphism
                                if level == 1:
                                    level2_button = NormalButton(290, 200, btn_level2, audio_manager)
                                elif level == 2:
                                    level3_button = NormalButton(290, 300, btn_level3, audio_manager)
                                
                                # Unlock level di OOP
                                levels[level + 1].unlock()
                            
                            quiz_number = 0
                            notif_quiz = ""
                            page = "level"
                else:
                    notif_quiz = "Jawaban Anda SALAH!"
                
                # Reset input
                input_text = ""
        
        # Reset flag klik mouse
        if not pygame.mouse.get_pressed()[0]:
            mouse_clicked = False
        
        # Tombol kembali (alternative handling dengan fungsi lama)
        if image_btn(btn_back, 20, 20):
            quiz_number = 0
            notif_quiz = ""
            page = "level"
    
    
    # PAGE: WINNER SCREEN 
    # ============================================
    elif page == "winner":
        # Background dengan warna khusus
        screen.fill((25, 25, 112))  
        
        # Efek kembang api sederhana (titik-titik putih)
        for _ in range(50):
            x = random.randint(0, WIDTH)
            y = random.randint(0, HEIGHT//2)
            radius = random.randint(1, 3)
            pygame.draw.circle(screen, (255, 255, 255), (x, y), radius)
        
        # Judul utama
        font_big = pygame.font.SysFont("arialblack", 50)
        win_text = font_big.render("SELAMAT!", True, (255, 215, 0))  # Gold color
        screen.blit(win_text, (WIDTH//2 - win_text.get_width()//2, 80))
        
        # Sub judul
        font_medium = pygame.font.SysFont("arialblack", 25)
        subtitle = font_medium.render("ANDA SANG PEMENANG!", True, (255, 255, 255))
        screen.blit(subtitle, (WIDTH//2 - subtitle.get_width()//2, 160))
        
        
        # Pesan konfirmasi
        font_small = pygame.font.SysFont("arial", 12)
        message = font_small.render("Kembali ke menu utama dalam 10 detik...", True, (200, 200, 200))
        screen.blit(message, (WIDTH//2 - message.get_width()//2, 380))
        
        # Timer untuk otomatis kembali ke menu
        current_time = pygame.time.get_ticks()
        if current_time - winner_timer > 10000:  # 10 detik
            page = "menu"
            # Reset semua status game
            quiz_number = 0
            notif_quiz = ""
            dialog_index = 0
            level_dialog_index = 0
            input_text = ""
            answered = []
    
    # UPDATE DISPLAY
    # ============================================
    pygame.display.update()

# CLEANUP DAN EXIT
# ============================================
pygame.quit()
sys.exit()